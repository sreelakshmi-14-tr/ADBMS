set serveroutput on;
accept n prompt 'enter the value of n:';
declare
cursor t_borrow is select amount from borrowB48;
n number;
b_amount t_borrow%rowtype;
tot number:=0; i number:=0;
begin
n:=&n;
open t_borrow;
while i<n
loop
fetch t_borrow into b_amount;
exit when t_borrow%notfound;
tot:=tot+b_amount.amount;
i:=i+1;
end loop;
dbms_output.put_line('The total loan amount for selected records:'||tot);
end;
/


/*
SQL> select * from borrowB48;

LOANN CNAME		 BNAME			AMOUNT
----- ------------------ ------------------ ----------
201   ANIL		 VRCE			  1000
206   MEHUL		 AJNI			  5000
311   SUNIL		 DHARAMPETH		  3000
375   PRAMOD		 VIRAR			  6000
481   KRANTI		 NEHURU PLACE		  3000
321   MANDHURI		 ANDHERI		  2000

6 rows selected.

SQL> @borrow.sql
enter the value of n:3
old   7: n:=&n;
new   7: n:=3;
The total loan amount for selected records:9000

PL/SQL procedure successfully completed.

*/

