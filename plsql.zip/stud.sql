set serveroutput on;
declare cursor s_marks is select rno,s1,s2,s3,s4 from student;
tot number; per number;
stud s_marks%rowtype;
begin
open s_marks;
dbms_output.put_line('___FEDERAL INSTITUTE OF SCIENCE AND TECHNOLOGY___');
dbms_output.put_line('******DEPARTMENT OF COMPUTER APPLICATIONS *****');
loop
fetch s_marks into stud;
exit when s_marks%notfound;
tot:=stud.s1+stud.s2+stud.s3+stud.s4;
per:=(tot/400)*100;
update student set total=tot,percentage=per where rno=stud.rno;
dbms_output.put_line(' Register number:'||stud.rno);
dbms_output.put_line('_________________________________');
dbms_output.put_line('subject '||'secured mark '||'max mark ');
dbms_output.put_line('DBMS '||stud.s1||' 100');
dbms_output.put_line('WP '||stud.s2||' 100');
dbms_output.put_line('CN '||stud.s3||' 100');
dbms_output.put_line('SE '||stud.s4||' 100');
dbms_output.put_line('Total marks obtained in four subjects:'||tot);
dbms_output.put_line('Percentage of marks in four subjects:'||per);
dbms_output.put_line('__________________________ _________________');
end loop;
end;
/
