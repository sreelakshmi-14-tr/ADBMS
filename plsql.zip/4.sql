set serveroutput on
accept acc_no prompt 'Enter the account number';
DECLARE

acno number(8,2);
CURSOR cur_emp IS SELECT actno from depositB48;

v_emp cur_emp%rowtype;

BEGIN

accno:=&acc_no;

DBMS_OUTPUT.PUT_LINE ('******************');

OPEN cur_emp;

FETCH cur_emp into v_emp;

WHILE cur_emp%found LOOP

DBMS_OUTPUT.PUT_LINE (v_emp.actno);



DBMS_OUTPUT.PUT_LINE ('******************');

FETCH cur_emp into v_emp; 
 
END LOOP;

CLOSE cur_emp;

END;

/


