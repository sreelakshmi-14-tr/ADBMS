set serveroutput on;
accept m1 prompt 'mark of subject 1:';
accept m2 prompt 'mark of subject 2:';
accept m3 prompt 'mark of subject 3:';
accept m4 prompt 'mark of subject 4:';
declare
m1 number; m2 number; m3 number; m4 number; tot number; per number;
begin
m1:=&m1;
m2:=&m2;
m3:=&m3;
m4:=&m4;
tot:=m1+m2+m3+m4;
per:=(tot/400)*100;
dbms_output.put_line('Total marks: '||tot);
dbms_output.put_line('percentage of marks: '||per);
end;
/


/*

SQL> @avg.sql
mark of subject 1:34
mark of subject 2:31
mark of subject 3:22
mark of subject 4:16
old   4: m1:=&m1;
new   4: m1:=34;
old   5: m2:=&m2;
new   5: m2:=31;
old   6: m3:=&m3;
new   6: m3:=22;
old   7: m4:=&m4;
new   7: m4:=16;
Total marks: 103
percentage of marks: 25.75

PL/SQL procedure successfully completed.

*/
