set serveroutput on
declare
 v_deposit depositB48%rowtype;
begin
 select * into v_deposit from depositB48 where actno='109';
dbms_output.put_line('no:' ||v_deposit.actno);
dbms_output.put_line('name:' ||v_deposit.cname);
dbms_output.put_line('branch:' ||v_deposit.bname);
dbms_output.put_line('amount:' ||v_deposit.amount);
end;
/


/*
SQL> @depo.sql
no:104
name:PRAMOD
branch:M.G.ROAD
amount:3210

PL/SQL procedure successfully completed.

*/


